
package fr.amongfr.itecheate.item;

import net.minecraftforge.registries.ObjectHolder;

import net.minecraft.item.crafting.Ingredient;
import net.minecraft.item.PickaxeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.Item;
import net.minecraft.item.IItemTier;
import net.minecraft.block.Blocks;

import fr.amongfr.itecheate.ItecheateModElements;

@ItecheateModElements.ModElement.Tag
public class CheatedPickaxeItem extends ItecheateModElements.ModElement {
	@ObjectHolder("itecheate:cheated_pickaxe")
	public static final Item block = null;
	public CheatedPickaxeItem(ItecheateModElements instance) {
		super(instance, 1);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new PickaxeItem(new IItemTier() {
			public int getMaxUses() {
				return 6346;
			}

			public float getEfficiency() {
				return 43.5f;
			}

			public float getAttackDamage() {
				return 24f;
			}

			public int getHarvestLevel() {
				return 75;
			}

			public int getEnchantability() {
				return 167;
			}

			public Ingredient getRepairMaterial() {
				return Ingredient.fromStacks(new ItemStack(Blocks.BEDROCK));
			}
		}, 1, 2.6f, new Item.Properties().group(ItemGroup.TOOLS).isImmuneToFire()) {
			@Override
			public boolean hasContainerItem() {
				return true;
			}

			@Override
			public ItemStack getContainerItem(ItemStack itemstack) {
				return new ItemStack(this);
			}

			@Override
			public boolean isRepairable(ItemStack itemstack) {
				return false;
			}
		}.setRegistryName("cheated_pickaxe"));
	}
}
