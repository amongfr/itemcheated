
package fr.amongfr.itecheate.item;

import net.minecraftforge.registries.ObjectHolder;

import net.minecraft.item.crafting.Ingredient;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.Item;
import net.minecraft.item.IItemTier;
import net.minecraft.item.AxeItem;
import net.minecraft.block.Blocks;

import fr.amongfr.itecheate.ItecheateModElements;

@ItecheateModElements.ModElement.Tag
public class CheatedAxeItem extends ItecheateModElements.ModElement {
	@ObjectHolder("itecheate:cheated_axe")
	public static final Item block = null;
	public CheatedAxeItem(ItecheateModElements instance) {
		super(instance, 2);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new AxeItem(new IItemTier() {
			public int getMaxUses() {
				return 6280;
			}

			public float getEfficiency() {
				return 61.5f;
			}

			public float getAttackDamage() {
				return 88f;
			}

			public int getHarvestLevel() {
				return 56;
			}

			public int getEnchantability() {
				return 150;
			}

			public Ingredient getRepairMaterial() {
				return Ingredient.fromStacks(new ItemStack(Blocks.BEDROCK));
			}
		}, 1, 7.799999999999999f, new Item.Properties().group(ItemGroup.TOOLS).isImmuneToFire()) {
			@Override
			public boolean hasContainerItem() {
				return true;
			}

			@Override
			public ItemStack getContainerItem(ItemStack itemstack) {
				return new ItemStack(this);
			}

			@Override
			public boolean isRepairable(ItemStack itemstack) {
				return false;
			}
		}.setRegistryName("cheated_axe"));
	}
}
