
package fr.amongfr.itecheate.item;

import net.minecraftforge.registries.ObjectHolder;

import net.minecraft.item.crafting.Ingredient;
import net.minecraft.item.ShovelItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.Item;
import net.minecraft.item.IItemTier;
import net.minecraft.block.Blocks;

import fr.amongfr.itecheate.ItecheateModElements;

@ItecheateModElements.ModElement.Tag
public class CheatedShovelItem extends ItecheateModElements.ModElement {
	@ObjectHolder("itecheate:cheated_shovel")
	public static final Item block = null;
	public CheatedShovelItem(ItecheateModElements instance) {
		super(instance, 4);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new ShovelItem(new IItemTier() {
			public int getMaxUses() {
				return 6280;
			}

			public float getEfficiency() {
				return 71f;
			}

			public float getAttackDamage() {
				return 23.400000000000002f;
			}

			public int getHarvestLevel() {
				return 104;
			}

			public int getEnchantability() {
				return 198;
			}

			public Ingredient getRepairMaterial() {
				return Ingredient.fromStacks(new ItemStack(Blocks.BEDROCK));
			}
		}, 1, 7.1f, new Item.Properties().group(ItemGroup.TOOLS).isImmuneToFire()) {
			@Override
			public boolean hasContainerItem() {
				return true;
			}

			@Override
			public ItemStack getContainerItem(ItemStack itemstack) {
				return new ItemStack(this);
			}

			@Override
			public boolean isRepairable(ItemStack itemstack) {
				return false;
			}
		}.setRegistryName("cheated_shovel"));
	}
}
